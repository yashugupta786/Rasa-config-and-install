import pandas as pd
import matplotlib.pyplot as plt
import string
from xgboost import XGBClassifier
import numpy as np
import re
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix
from sklearn import metrics
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import SGDClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import VotingClassifier
from sklearn.metrics import accuracy_score, precision_score, make_scorer
import nltk
lemma = nltk.WordNetLemmatizer()
from sklearn.feature_extraction.text import TfidfVectorizer,CountVectorizer
from io import StringIO
df=pd.read_excel("final_nps.xlsx")
# print(df.columns)
df = df[pd.notnull(df['Product_NPS_Comment'])]
df['category_id'] = df['Internal Review Label'].factorize()[0]
# cols=['Internal Review Label','category_id']
category_id_df = df[['Internal Review Label', 'category_id']].drop_duplicates().sort_values('category_id')
category_to_id = dict(category_id_df.values)
id_to_category = dict(category_id_df[['category_id', 'Internal Review Label']].values)

print(df.head())
#----------------Ploting the data for class imbalance-----------------------------
fig = plt.figure(figsize=(8,6))
df.groupby('Internal Review Label').Product_NPS_Comment.count().plot.bar(ylim=0)
plt.show()
feature_questions_punct=[]
_feature_questions=[]
_feature_questions_noun=[]
_feature_questions_verb=[]
all_comment=df["Product_NPS_Comment"].tolist()
feature_questions_lwr = [x.lower() for x in all_comment]
for i in feature_questions_lwr:
    translation_table = dict.fromkeys(map(ord, string.punctuation), ' ')
    string2 = i.translate(translation_table)  # translating string1
    feature_questions_punct.append(string2)
feature_questions_spc = [s for s in feature_questions_punct if s]
for i in feature_questions_spc:
    _feature_questions.append(re.sub('\s+', ' ', i).strip())
print("lemma start")
feature_questions_noun = [[lemma.lemmatize(word, 'n') for word in sentence.split(" ")] for sentence in
                          _feature_questions]
for i in feature_questions_noun:
    _feature_questions_noun.append(" ".join(i))
feature_questions_verb = [[lemma.lemmatize(word, 'v') for word in sentence.split(" ")] for sentence in
                          _feature_questions_noun]
for i in feature_questions_verb:
    _feature_questions_verb.append(" ".join(i))
label=df["category_id"]

labels=label
tfidf = TfidfVectorizer(
                        ngram_range=(1, 2))
features = tfidf.fit_transform(_feature_questions_verb).toarray()
print("Each of the %d comments is represented by %d features (TF-IDF score of unigrams and bigrams)" %(features.shape))

models = [
    RandomForestClassifier(n_estimators=500, max_depth=5, random_state=0),
    LinearSVC(),
    MultinomialNB(),
    LogisticRegression(random_state=0),

    SGDClassifier(loss='log',n_jobs=-1,max_iter=400,
              random_state=0,
              shuffle=True,
              tol=0.01)
]

# 5 Cross-validation
CV = 5
cv_df = pd.DataFrame(index=range(CV * len(models)))

entries = []
for model in models:
    model_name = model.__class__.__name__
    accuracies = cross_val_score(model, features, labels, scoring='accuracy', cv=CV)
    for fold_idx, accuracy in enumerate(accuracies):
        entries.append((model_name, fold_idx, accuracy))

cv_df = pd.DataFrame(entries, columns=['model_name', 'fold_idx', 'accuracy'])
print(cv_df)
cv_df.to_excel("test_model.xlsx")

mean_accuracy = cv_df.groupby('model_name').accuracy.mean()
std_accuracy = cv_df.groupby('model_name').accuracy.std()

acc = pd.concat([mean_accuracy, std_accuracy], axis= 1,
          ignore_index=True)
acc.columns = ['Mean Accuracy', 'Standard deviation']
print(acc)

