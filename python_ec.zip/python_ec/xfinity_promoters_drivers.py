import pandas as pd
import matplotlib.pyplot as plt
from nltk.corpus import stopwords
stopword = set(stopwords.words('english'))
from wordcloud import WordCloud, STOPWORDS
import re
df_pd=pd.read_excel("promoters_drivers.xlsx")
reviews=list(df_pd['Q_COMCAST_GLOBAL_LTR_COMMENT'])
reviews= list (map(lambda x:str(x).lower(), reviews))
reviews= list (map(lambda x:re.sub('[^A-Za-z\s]','',x), reviews))
df_pd["final_text"]=pd.Series(reviews)
tex=''
for ind,rev in enumerate(reviews):
    tokens=rev.split()
    tokens=[token for token in tokens if token not in stopword]
    reviews[ind]=' '.join(tokens)
    tex+=' '.join(tokens)
##optional step- create word cloud
# wordcloud = WordCloud(width = 800, height = 800, background_color ='white',  min_font_size = 10).generate(tex)
#
# plt.figure(figsize = (8, 8), facecolor = None)
# plt.imshow(wordcloud)
# plt.axis("off")
# plt.tight_layout(pad = 0)
# plt.show()
# plt.savefig('promoters_clouds.png')
# exit()
all_tokens = tex.split()
from collections import Counter

word_count_200 = Counter(all_tokens).most_common(200)
l1 = []
l2 = []
for tup in word_count_200:
    l1.append(tup[0])
    l2.append(tup[1])

worddf = pd.DataFrame()
worddf['word'] = pd.Series(l1)
worddf['count'] = pd.Series(l2)
#
# newdf.to_excel('freqwords.xlsx')
print(worddf.head())

drivers=pd.read_excel('drivers_prom.xlsx')
joined_worddf=pd.merge(worddf,drivers,how='left',on='word')
# joined_worddf.to_excel('joined_worddf_drivers_detractor_passive.xlsx') ##exporting the df to do the manual tagging (if needed)
# joined_worddf.dropna().head()
#
# new_drivers_df=pd.read_excel('joined_worddf_drivers_detractor_passive.xlsx').dropna()
# del new_drivers_df['count']

dict_df= drivers
words=list(dict_df['word'])
cats=list(dict_df['cat'])
words_dict=dict(zip(words,cats))
print(words_dict)


wdf=df_pd

# wdf=wdf[wdf['Q_COMCAST_GLOBAL_LTR_COMMENT']!='-']
# wdf=wdf.reset_index()
# wdf['final_text']=pd.Series(reviews)
##new columns
wdf['customer services']=pd.Series([0]* wdf.shape[0])
wdf['price']=pd.Series([0]* wdf.shape[0])
wdf['product and features']=pd.Series([0]* wdf.shape[0])
wdf['technical']=pd.Series([0]* wdf.shape[0])
# wdf['installing']=pd.Series([0]* wdf.shape[0])
# wdf['sales representative']=pd.Series([0]* wdf.shape[0])
# wdf['technician visit']=pd.Series([0]* wdf.shape[0])
# wdf['product']=pd.Series([0]* wdf.shape[0])
# wdf['service']=pd.Series([0]* wdf.shape[0])
# wdf['offers and deals']=pd.Series([0]* wdf.shape[0])
# wdf['product reliability']=pd.Series([0]* wdf.shape[0])






for ind, row in wdf.iterrows():
    text = row['final_text']

    for word in list(words_dict.keys()):
        try:
            if word in text:
                cat = words_dict[word]
                amount = row[cat]
                wdf.at[ind, cat] = amount + 1
        except:
            continue


def max_cat(all_cat, cat):
    m = max(all_cat)
    cat1 = cat
    flag = 0
    for cat in all_cat:
        if cat == m:
            flag += 1
    if flag > 1:
        return 'na'
    else:
        i = all_cat.index(m)
        # return cat
        cc = cat1[i]
        return cc


def final_cat(all_cat, cat):
    m = max(all_cat)
    if m==0:
        return 'na'
    cat1 = cat
    #flag = 0
    result=[]
    for ind,cat in enumerate(all_cat):
        if cat == m:
            result.append(cat1[ind])
            #flag += 1
    return ','.join(result)



# cat = ['feature', 'customer service', 'techinal', 'price','installing','sales representative','technician visit',
#        'product','service','offers and deals','product reliability']
cat=['customer services','product and features','price','technical']
cats = []
for ind, row in wdf.iterrows():
    all_val = []
    for each_cat in cat:
        all_val.append(row[each_cat])
    cats.append(final_cat(all_val, cat))

wdf['final_cat'] = pd.Series(cats)
wdf.head(9)

wdf_na=wdf[wdf['final_cat']=='na']
wdf_cat=wdf[wdf['final_cat']!='na']
wdf_cat.head(3)
# cri1=wdf_na.feature >0
cri2=wdf_na.price >0
cri3=wdf_na.technical >0
cri4=wdf_na['customer services'] >0
# cri5=wdf_na['installing'] >0
# cri6=wdf_na['sales representative'] >0
# cri7=wdf_na['technician visit'] >0
# cri8=wdf_na['product'] >0
# cri9=wdf_na['service'] >0
# cri10=wdf_na['offers and deals'] >0
cri11=wdf_na['product and features'] >0

cri_all= cri2 & cri3 &cri4 & cri11
wdf_notnan=wdf_na[cri_all]

# cri1=wdf_na.feature == 0
cri2=wdf_na.price == 0
cri3=wdf_na.technical == 0
cri4=wdf_na['customer services'] == 0
# cri5=wdf_na['installing'] ==0
#
# cri6=wdf_na['sales representative'] ==0
# cri7=wdf_na['technician visit'] ==0
# cri8=wdf_na['product'] ==0
# cri9=wdf_na['service'] ==0
# cri10=wdf_na['offers and deals'] ==0
cri11=wdf_na['product and features'] ==0


cri_all= cri2 & cri3 &cri4 & cri11
wdf_isna=wdf_na[cri_all]
wdf_isna.reset_index(inplace = True)

service=['service','comcast','services']

for ind,row in wdf_isna.iterrows():
    for wr in service:
        if wr in str(row['final_text']):
            wdf_isna.loc[ind,'final_cat']='service'

fdf=wdf_cat.append(wdf_isna)
fdf1=fdf.append(wdf_na)
for ind , row in fdf1.iterrows():
   if row["final_text"]=="price":
       fdf1.loc[ind, 'price'] = 1

fdf1.to_excel(r'0000.xlsx')####where entries of 2 categories are equal and more than zero. They have been given 'na'.
##observe a pattern and update them. accordingly
