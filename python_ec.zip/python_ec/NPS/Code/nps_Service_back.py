__author__ = "Yashu Gupta"
from flask import Flask, jsonify
import json, requests
from flask_cors import CORS, cross_origin
from flask import json
from flask.globals import request
import pandas as pd
from Code import tf_df, tst_chat, pred_nps_v2

nps_obj = tf_df.Classify_query()
Rf_obj = pred_nps_v2.Nps_pred()
# ---------------------------------------------
app = Flask(__name__)
CORS(app)


# ----------------------------------------------
@app.route('/NpsPredictor', methods=['POST'])
@cross_origin()
def GetIntent():
    try:
        global Text_classfier
        global RF_TEXT_CLASSIFIER
        new_df = pd.DataFrame()
        test_frame = pd.DataFrame()
        max_value = 0
        max_key = 0
        chat_data = []
        chat_data_test = []
        Detractor_prob = []
        promoter_prob = []
        passive_prob = []
        pred_detractor = []
        pred_promter = []
        pred_passive = []
        feature_names = ["DeadAirInstances", 'DeadAirTotalMinutes', "chat_length", "appreciation",
                         "duration", "esclation", "negative_words",
                         "Detractor_prob", "passive_prob", "promoter_prob"]

        all_params = request.form.get("params")
        if str(all_params) == "training":
            f = request.files['file']
            training_data = pd.read_csv(f)
            flag = nps_obj.columns_csv(training_data)

            if flag == True:
                try:
                    new_df = pd.concat([new_df, training_data], ignore_index=True)
                    labels = {'Promoters': 1, 'Detractors': 0, 'Passives': 2}
                    new_df["NPS"] = [labels[item] for item in new_df["NPS"]]
                    oversample = dict(new_df["NPS"].value_counts())
                    max_key, max_value = max(oversample.items(), key=lambda x: x[1])
                    Text_classfier = nps_obj.ml_training(new_df, max_key, max_value)
                    for i, row in new_df.iterrows():
                        filtered_data = nps_obj.fetch_interpreted(str(row['contentTextInternal']))[0]
                        chat_data.append(filtered_data)
                    new_df.drop('contentTextInternal', axis=1, inplace=True)
                    new_df["contentTextInternal"] = chat_data
                    for i, row in new_df.iterrows():
                        p_category_prob = Text_classfier.predict_proba([row["contentTextInternal"]])[0]
                        Detractor_prob.append(p_category_prob[0])
                        promoter_prob.append(p_category_prob[1])
                        passive_prob.append(p_category_prob[2])
                    df = pd.DataFrame({"Detractor_prob": Detractor_prob,
                                       "promoter_prob": promoter_prob, "passive_prob": passive_prob})
                    frame_NPS = pd.concat([new_df, df], axis=1)
                    frame_NPS.drop("same_row", axis=1, inplace=True)
                    RF_TEXT_CLASSIFIER, accuracy, f1score = Rf_obj.ml_npstrain_model(frame_NPS, feature_names, max_key,
                                                                                     max_value)
                    return json.dumps(
                        {"Status": "SUCCESS", "Accuracy": (accuracy), "Reason": "Model trained successfully"})
                except Exception as e:
                    return json.dumps(
                        {'Status": "ERROR", "DATA": None, "Reason": "error in trainng the model for CSV data'})
            else:
                return json.dumps({"Status": "SUCCESS", "DATA": ("data is not in correct format"),
                                   "Reason": "columns does not match in try different CSV"})
        if str(all_params) == "predict":
            if "file" not in request.files:
                detractor = []
                promot = []
                passive = []
                online_data = tst_chat.online_mode
                chat = online_data[7]
                filtered_chat = nps_obj.fetch_interpreted(str(chat))[0]
                cateogary_prob = Text_classfier.predict_proba([filtered_chat])[0]
                det = cateogary_prob[0]
                promo = cateogary_prob[1]
                passi = cateogary_prob[2]
                online_data.append(det)
                online_data.append(promo)
                online_data.append(passi)
                online_frame = pd.DataFrame([online_data], columns=tst_chat.cols_name)
                pred_data = Rf_obj.predict_NPS(RF_TEXT_CLASSIFIER, online_frame, feature_names)
                dict_frame = pred_data.to_dict("list")
                return json.dumps(dict_frame)


            else:
                f = request.files["file"]
                test_new_df = pd.read_csv(f)
                check = nps_obj.columns_csv(test_new_df)
                if check == True:
                    labels = {'Promoters': 1, 'Detractors': 0, 'Passives': 2}
                    test_new_df["NPS"] = [labels[item] for item in test_new_df["NPS"]]
                    for i, row in test_new_df.iterrows():
                        filtered_data1 = nps_obj.fetch_interpreted(str(row['contentTextInternal']))[0]
                        chat_data_test.append(filtered_data1)
                    test_new_df.drop('contentTextInternal', axis=1, inplace=True)
                    test_new_df["contentTextInternal"] = chat_data_test
                    for i, row in test_new_df.iterrows():
                        p_category_prob = Text_classfier.predict_proba([row["contentTextInternal"]])[0]
                        pred_detractor.append(p_category_prob[0])
                        pred_promter.append(p_category_prob[1])
                        pred_passive.append(p_category_prob[2])
                    test_df = pd.DataFrame({"Detractor_prob": pred_detractor,
                                            "promoter_prob": pred_promter, "passive_prob": pred_passive})
                    frame_test_NPS = pd.concat([test_new_df, test_df], axis=1)
                    pred_data = Rf_obj.predict_NPS(RF_TEXT_CLASSIFIER, frame_test_NPS, feature_names)
                    final_data = pred_data.to_dict('list')
                    return json.dumps(final_data)
    except Exception as e:
        return json.dumps({'Status": "ERROR", "DATA": None, "Reason": "error in reading file and trainng the model '})


# -------------------------------------------------------------------------
def startAPIs():
    try:
        app.run("192.168.54.74", port=(8080), debug=False, threaded=True)
        app.run()
    except Exception as e:
        raise ("APIs not started Exception (startAPIs ) at : " + str("192.168.54.74") + ":" + str(
            8080) + " due to :" + str(e))


if __name__ == '__main__':
    startAPIs()
