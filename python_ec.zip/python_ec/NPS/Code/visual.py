import pandas as pd
import nltk
from sklearn.model_selection import train_test_split
from matplotlib import pyplot
from sklearn.utils import resample
import pylab as pl
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, accuracy_score,f1_score
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score
lemma = nltk.WordNetLemmatizer()
from sklearn.multiclass import OneVsRestClassifier
training_data = pd.read_csv("./Final_1.15.csv", encoding="iso-8859-1")
training_data.fillna(0, inplace=True)
TEXT_CLASSIFIER = None
# print(training_data["NPS"].value_counts())
# exit()
feature_names = ["DeadAirInstances", 'DeadAirTotalMinutes', "chat_length", "appreciation",
                 "duration", "esclation", "negative_words",
                 "Detractor_prob","passive_prob","promoter_prob"]
from sklearn.decomposition import PCA
class Nps_pred(object):
    def __init__(self,df):
        self.dataframe=df


    def ml_train_model(self):

        try:
            global TEXT_CLASSIFIER
            datafrm=self.dataframe
            df_majority = datafrm[datafrm.NPS == 1]  # 1== promoters
            df_minority1 = datafrm[datafrm.NPS == 0]  # 0=Detractor
            df_minority2 = datafrm[datafrm.NPS == 2]  # 2=passives

            df_minority_upsampled1 = resample(df_minority1,
                                              replace=True,  # sample with replacement
                                              n_samples=4566,  # to match
                                              # majority class
                                              random_state=123)

            df_minority_upsampled2 = resample(df_minority2,
                                              replace=True,  # sample with replacement
                                              n_samples=3000,  # to match
                                              # majority class
                                              random_state=123)
            new_df = pd.concat([df_majority, df_minority_upsampled1, df_minority_upsampled2])

            #----------------------------------------------------------------------------------
            # feature_names = ["DeadAirInstances", 'DeadAirInstances', "chat_length", "appreciation",
            #                  "duration", "esclation", "negative_words",
            #                  "Detractor_prob","passive_prob","promoter_prob"]
            X = new_df[feature_names]
            y = new_df["NPS"]
            # print(X)
            X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                                test_size=0.1,
                                                                random_state=42)

            new_df.plot(kind="scatter", x="DeadAirInstances", y="NPS")

            text_classifier = RandomForestClassifier(n_jobs=-1, n_estimators=500, min_samples_leaf=1, max_depth=30, random_state=137)
            TEXT_CLASSIFIER = text_classifier.fit(X_train, y_train)
            pred=TEXT_CLASSIFIER.predict(X_test)
            accuracy=accuracy_score(y_test,pred)
            print(accuracy)

            print("F1 Score ",f1_score(y_test, pred, average="macro"))
            global flag
            flag = True
        except Exception as exception:
            print(str(exception))

    def get_predictions(self,query_points):
        global TEXT_CLASSIFIER
        if TEXT_CLASSIFIER is None:
            self.ml_train_model()
            print("faq _____fit again___")
        pred = TEXT_CLASSIFIER.predict(query_points)

        return pred


if __name__ == "__main__":
    import numpy as np
    obj = Nps_pred(training_data)
    obj.ml_train_model()
