online_mode=[0.954507459,4,"Detractors","8155100512042411",0,10012086,2777.333333,'''"<B>CHAT STARTED AT</B> 12:43 AM (16 Sep 2018)
EPIFANIA DIAZ 12:43 AM : Cancel Boxing Match Canelo Vs. GGG 

system 12:43 AM : You are now chatting with Aakash 

Aakash 12:44 AM : <p>Hi EPIFANIA, thank you for contacting Xfinity Chat Support.ÃƒÂ‚Ã‚Â  My name is Aakash.ÃƒÂ‚Ã‚Â </p>
 

EPIFANIA DIAZ 12:44 AM : I want to cancel the boxing match i just ordered 

Aakash 12:45 AM : Let me quickly pull up your account so that I can assist further .ÃƒÂ‚Ã‚Â For account verification, please provide your full name and complete service address along with the zip code. 

EPIFANIA DIAZ 12:45 AM : Epifania Diaz 

EPIFANIA DIAZ 12:45 AM : 347 Dale Dr. San Jose Ca. 95127 

Aakash 12:46 AM : Perfect .ÃƒÂ‚Ã‚Â Please allow me a couple of minutes to check your account information.ÃƒÂ‚Ã‚Â  

Aakash 12:48 AM : Thank you for waiting. 

EPIFANIA DIAZ 12:49 AM : It turns out a friend ordered it and i want to cancel 

Aakash 12:50 AM : I see that you just ordered the boxing event for $84.99 , however as you want to cancel it , Please stay connected while I remove it for you . 

EPIFANIA DIAZ 12:50 AM : okay 

Aakash 12:52 AM : I apologize as it is taking a bit long . Please stay connected while I am removing it for you .ÃƒÂ‚Ã‚Â  

EPIFANIA DIAZ 12:52 AM : Okay 

EPIFANIA DIAZ 12:53 AM : Okay it stopped 

Aakash 12:54 AM : Thank you for waiting. 

Aakash 12:54 AM : Yes please I have removed it from the account . 

Aakash 12:54 AM : Are we good so far ? 

EPIFANIA DIAZ 12:54 AM : There is no charge correct? 

Aakash 12:54 AM : Yes , that is correct . 

EPIFANIA DIAZ 12:54 AM : Okay thank you so much 

EPIFANIA DIAZ 12:54 AM : that is all 

Aakash 12:55 AM : I hope I have addressed all your concerns today and provided you satisfactory resolution. 

system 12:55 AM : EPIFANIA DIAZ has left the chat 

system 12:56 AM : Aakash has ended the chat 



<B>CHAT ENDED AT</B> 12:56 AM (16 Sep 2018)"
''',0,11.5,0,0]


cols_name=['DeadAirInstances','DeadAirTotalMinutes','NPS','accountNumber','appreciation','caseId','chat_length','contentTextInternal',
           'derogatory_words','duration','esclation','negative_words','Detractor_prob','promoter_prob','passive_prob']
