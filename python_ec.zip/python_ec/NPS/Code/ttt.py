if "passive_prob" not in test_data.columns:
    test_data = test_data[feature_name]
else:
    f = feature_name + ["passive_prob"]
    test_data = test_data[f]
