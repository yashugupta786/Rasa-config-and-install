# -*- coding: utf-8 -*-
"""
Created on 12:35
"""
NPS_values = ['Detractors','Promoters','Passives']
weighted_cols = ['DeadAirInstances','derogatory_words', 'negative_words',
                 'appreciation','esclation']

cols = ['DeadAirInstances','DeadAirTotalMinutes','NPS',
      'accountNumber','caseId','chatStartDateTime',
      'contentTextInternal','chat_length','subject','derogatory_words',
      'negative_words','duration','appreciation','esclation']

mean_cols = ['accountNumber','DeadAirInstances','DeadAirTotalMinutes',
           'chat_length', 'derogatory_words','negative_words','duration',
           'appreciation', 'esclation']

train_cols = ['caseId','accountNumber','contentTextInternal','DeadAirInstances',
              'DeadAirTotalMinutes', 'chat_length', 'derogatory_words',
              'negative_words','duration','appreciation', 'esclation','NPS']
