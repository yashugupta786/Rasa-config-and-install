import pandas as pd
import os.path
from os import path
from sklearn.utils import resample
import string
import re
import nltk
import numpy as np
import itertools
from sklearn.metrics import classification_report
lemma = nltk.WordNetLemmatizer()
from sklearn.utils.multiclass import unique_labels
from sklearn.metrics import confusion_matrix, accuracy_score, f1_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, confusion_matrix, precision_recall_fscore_support
import seaborn as sns

df = pd.read_excel("D:\\YashuProjects\\NPS_model_prod\\final_nps.xlsx")
import matplotlib.pyplot as plt
TEXT_CLASSIFIER = None
class Comments_suggestions(object):
    def __init__(self, df):
        self.my_dataframe = df
        df = self.my_dataframe[pd.notnull(self.my_dataframe['Product_NPS_Comment'])]
        df['category_id'] = df['Internal Review Label'].factorize()[0]
        # cols=['Internal Review Label','category_id']
        category_id_df = df[['Internal Review Label', 'category_id']].drop_duplicates().sort_values('category_id')
        self.category_to_id = dict(category_id_df.values)
        self.id_to_category = dict(category_id_df[['category_id', 'Internal Review Label']].values)

        # ----------------Ploting the data for class imbalance-----------------------------
        fig = plt.figure(figsize=(8, 6))
        df.groupby('Internal Review Label').Product_NPS_Comment.count().plot.bar(ylim=0)
        plt.show()
        feature_questions_punct = []
        _feature_questions = []
        _feature_questions_noun = []
        _feature_questions_verb = []
        print(df["category_id"].value_counts())
        self.feature_questions = df["Product_NPS_Comment"].tolist()
        self.labels = df["category_id"]

    def comments_train(self):
        try:
            _feature_questions = []
            _feature_questions_noun = []
            _feature_questions_verb = []
            feature_questions_punct = []
            global TEXT_CLASSIFIER
            feature_lables = self.labels
            feature_questions_lwr = [x.lower() for x in self.feature_questions]
            for i in feature_questions_lwr:
                translation_table = dict.fromkeys(map(ord, string.punctuation), ' ')
                string2 = i.translate(translation_table)  # translating string1
                feature_questions_punct.append(string2)
            feature_questions_spc = [s for s in feature_questions_punct if s]
            for i in feature_questions_spc:
                _feature_questions.append(re.sub('\s+', ' ', i).strip())
            print("lemma start")
            feature_questions_noun = [[lemma.lemmatize(word, 'n') for word in sentence.split(" ")] for sentence in
                                      _feature_questions]
            for i in feature_questions_noun:
                _feature_questions_noun.append(" ".join(i))
            feature_questions_verb = [[lemma.lemmatize(word, 'v') for word in sentence.split(" ")] for sentence in
                                      _feature_questions_noun]
            for i in feature_questions_verb:
                _feature_questions_verb.append(" ".join(i))
            print("lemma finish")
            interpretation_all_data = feature_lables
            print(_feature_questions_verb)
            print(interpretation_all_data)
            X_train, X_test, y_train, y_test = train_test_split(_feature_questions_verb, interpretation_all_data,test_size=0.1,
                                                                random_state=42)
            print("TFIDF vectorization start")
            tfidf_vectorizer = TfidfVectorizer(ngram_range=(1, 2))
            text_classifier = Pipeline([
                ('vectorizer', tfidf_vectorizer),
                ('clf', SGDClassifier(loss='log',
                                      n_jobs=-1,
                                      max_iter=400,
                                      random_state=0,
                                      shuffle=True,
                                      tol=0.01))
            ])
            print("model training start -----------------")
            TEXT_CLASSIFIER = text_classifier.fit(X_train, y_train)
            pred = TEXT_CLASSIFIER.predict(X_test)
            # accuracy = accuracy_score(y_test, pred)
            # print(accuracy)
            # F1score = f1_score(y_test, pred, average="macro")

            testdf=pd.DataFrame(X_test,columns=["all_comments"])
            testdf["original_prediction"]=y_test.values
            testdf["prediction"]=pred
            testdf["prediction"]=testdf["prediction"].map(self.id_to_category)
            testdf["original_prediction"]=testdf["original_prediction"].map(self.id_to_category)
            testdf.to_csv("pred_v1.csv",index=False)
            global flag
            flag = True
        except Exception as exception:
            print(str(exception))

    def fetch_interpreted(self, question):
        global TEXT_CLASSIFIER
        if TEXT_CLASSIFIER is None:
            self.comments_train()
            print("faq _____fit again___")
        query = [question]
        query_label = []
        _feature_query = []
        _feature_questions_noun_user = []
        _feature_questions_verb_user = []
        feature_pred_punct = []
        feature_pred_lwr = [str(x).lower() for x in query]
        for i in feature_pred_lwr:
            translation_table = dict.fromkeys(map(ord, string.punctuation), ' ')
            string2 = i.translate(translation_table)  # translating string1
            feature_pred_punct.append(string2)
        feature_questions_spc = [s for s in feature_pred_punct if s]
        for i in feature_questions_spc:
            _feature_query.append(re.sub('\s+', ' ', i).strip())
        feature_questions_noun = [[lemma.lemmatize(word, 'n') for word in sentence.split(" ")] for sentence in
                                  _feature_query]
        for i in feature_questions_noun:
            _feature_questions_noun_user.append(" ".join(i))
        feature_questions_verb = [[lemma.lemmatize(word, 'v') for word in sentence.split(" ")] for sentence in
                                  _feature_questions_noun_user]
        for i in feature_questions_verb:
            query_label.append(" ".join(i))
        # print(query_label)
        pred = TEXT_CLASSIFIER.predict(query_label)
        print(pred)
        for i,j in self.category_to_id.items():
            if pred[0]==j:
                print(i,j)
                return i
#
if __name__ == '__main__':
    obj1 = Comments_suggestions(df)
    if path.exists('D:\\YashuProjects\\NPS_model_prod\\reponses.xlsx'):
        final_df=pd.DataFrame()
        testing_data=pd.read_excel("D:\\YashuProjects\\NPS_model_prod\\reponses.xlsx")
        predicted_label=[]
        testing_data = testing_data[pd.notnull(testing_data['Product NPS Comment'])]
        for i, row in testing_data.iterrows():
            p_category= obj1.fetch_interpreted(str(row['Product NPS Comment']))
            print(p_category)
            predicted_label.append(p_category)
        testing_data["predicted_label"] = predicted_label
        # df1 = pd.DataFrame({"predicted_label": predicted_label,
        #                    })
        # new_df = pd.concat([testing_data, df1], axis=1)
        # # new_df.to_csv("Final_1.15.csv", index=False)
        testing_data.to_excel("FinalTesting_retail_v3.xlsx", index=False)
    else:
        obj1.comments_train()


#
#
# obj1 = Comments_suggestions(df)
# obj1.comments_train()