__author__="YASHU GUPTA"
#-------------------------ALL IMPORTS----------------------------------------------------
server = "ECXCIAZDEV01"
port = 10433
db1 = "dbs4x_qa"
uname = "webusercima"
pword = "webusercima"
#---------------------------------------THRESHOLD--------------------------------
threshold = 0.50
inner_threshold=0.50
#------------------------time for database refresh------------------------------------------------
time1="gauravyashu" #8:40
# time2="yashu"   #10:00

#---------------------------------------API url--------------------------------------

api_url="192.168.54.74"
port_num=1995

#------------------------------------email trigger---------------
FROM = "yashu.gupta@eclerx.com"
TO = "yashu.gupta@eclerx.com"
CC = "yashu.gupta@eclerx.com"
smtp_url='smtp1.eclerx.com'
#---------------------------------------------

table="CoreAttemptedQuestion_CommentsValidation"