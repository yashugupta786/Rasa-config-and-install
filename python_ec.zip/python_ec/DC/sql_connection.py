import pyodbc
import config
class sql_connection(object):
    def __init__(self):
        pass

    def sql_connect(self):
        try:
            server=config.server
            port=config.port
            db1=config.db1
            uname=config.uname
            pword=config.pword

            connStr ="Driver={};Server={},{};Database={};uid={};pwd={}".format(
                '{SQL Server Native Client 11.0}',server,port,db1,uname,pword)

            connection =pyodbc.connect(connStr)
            cursor = connection.cursor()
            return cursor
        except Exception as e:
            raise Exception("error in the database connectivity" + str(e))
