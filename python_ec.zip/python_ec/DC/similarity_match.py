__author__="YASHU GUPTA" \
           "This file used to find similarity using vectorization of words using gensim and sequence matching"
import pandas as pd
from difflib import SequenceMatcher
import string
import re, math
from collections import Counter
from datetime import datetime
import config
import re
import stop_list

threshold=config.threshold
dumped=[]
stop_removd_list=[]
df=pd.DataFrame()
WORD = re.compile(r'\w+')
#----------------------------------CLASS DEFINED---------------------------------------------------
#
class s4x(object):
    def __init__(self):
        pass

    def text_to_vector(self,text):
        words = WORD.findall(text)
        return Counter(words)

    def get_cosine(self,vec1, vec2):
        intersection = set(vec1.keys()) & set(vec2.keys())
        numerator = sum([vec1[x] * vec2[x] for x in intersection])

        sum1 = sum([vec1[x] ** 2 for x in vec1.keys()])
        sum2 = sum([vec2[x] ** 2 for x in vec2.keys()])
        denominator = math.sqrt(sum1) * math.sqrt(sum2)

        if not denominator:
            return 0.0
        else:
            return float(numerator) / denominator

    def threaded_env(self,cursor,src_data):
        global dumped
        global stop_removd_list
        global df
        results=[]
        k = 0
        src_data = src_data.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace(",","&#44;").replace("&#", "&amp;#").replace("'", "&apos;").replace("’", "&apos;").strip()
        print("original",src_data)
        pattern = re.compile(r'\b(' + r'|'.join(stop_list.list1_words) + r')\b\s*')
        src_data = pattern.sub('', src_data.lower().strip())
        if len(src_data)==0:
            results.append({
                    'score': 0,
                    'doc': "empty string"})
            return results

        else:
            src_data=self.text_to_vector(src_data)
            now = datetime.now()
            current_time = now.strftime("%H:%M %p")
            print(current_time)

            if list(src_data.keys())[0]==config.time1:
                dumped=[]
                stop_removd_list=[]
                df=pd.DataFrame()
                print("database refreshed in ist time zone")
                start_database=datetime.now()
                cursor.execute(
                    "SELECT Comments FROM CoreAttemptedQuestion_CommentsValidation")
                for row in cursor.fetchall():
                    dumped.append(row[0])
                dumped1 = int(len(dumped) / 10)
                ten_dumped_ = dumped[9 * dumped1 + 1:]
                for i in ten_dumped_:
                    pattern = re.compile(r'\b(' + r'|'.join(stop_list.list1_words) + r')\b\s*')
                    stop_rmvd = pattern.sub('', i.lower().strip())
                    stop_remvd1=self.text_to_vector(stop_rmvd)
                    stop_removd_list.append(stop_remvd1)
                df["original"] = ten_dumped_
                df["stopwords_removed"] = stop_removd_list
                print("checking len of dump in time 1", len(ten_dumped_))
                print("time in database and stop words",datetime.now()-start_database)
            else:
                if len(dumped)==0:
                    cursor.execute(
                        "SELECT Comments FROM CoreAttemptedQuestion_CommentsValidation")
                    for row in cursor.fetchall():
                        dumped.append(row[0])
                    dumped1 = int(len(dumped) / 10)
                    ten_dumped_ = dumped[9 * dumped1 + 1:]
                    for i in  ten_dumped_:
                        pattern = re.compile(r'\b(' + r'|'.join(stop_list.list1_words) + r')\b\s*')
                        stop_rmvd= pattern.sub('', i.lower().strip())
                        stop_remvd1 = self.text_to_vector(stop_rmvd)
                        stop_removd_list.append(stop_remvd1)
                    df["original"]=ten_dumped_
                    df["stopwords_removed"]=stop_removd_list
                    print("in else if",len(ten_dumped_))
                else:
                    print("printing_old data for vectorization")
                    print(df.shape)
            try:
                final_start = datetime.now()
                for idx, item in df.iterrows():
                    j = item['original']
                    l = item["stopwords_removed"]
                    if len(results) != 0:
                        break
                    else:
                        sim_score = self.get_cosine(src_data,l)
                        sim_score = "{0:.2f}".format(sim_score)
                        if float(sim_score) > threshold:
                            results.append({
                                'score': float(sim_score)*100,
                                'doc': j,
                                # 'stop_removed': l
                            })

                print("business logic time",datetime.now()-final_start)
                if len(results) == 0:
                    results.append({
                        'score': 0,
                        'doc': "Did not match at 50 % threshold"})
                return results
            except Exception as e:
                raise Exception("error in dumping data from database: " + str(e))


# if __name__ == '__main__':
#     agents = 4
#     chunksize = 2
#     obj1=s4x()
#     source_data ='''You asked the questions to understand the customer&apos;s concern as related to lower the bill and wanted to remove the Cable and Phone service. You also asked the customer about Cable and phone services requirements. The customer believed that you understood her requirements and would give the best resolution. However&amp;#44; you could have asked the customer about Internet and XHS services utilization at customer&apos;s home&amp;#44; which could have given you the clarity about customer&apos;s needs and helped you to give the best resolution to the customer.'''
#     start = datetime.now()
#     results=obj1.threaded_env(check_data,source_data)
#     print(results)
#     # with Pool(processes=agents) as pool:
#     #     result = pool.map(threaded_env, [check_data], chunksize)
#     #     print(result)
#     print(datetime.now()-start)
#
