__author__="YASHU GUPTA" \
           "This file used to find similarity using vectorization of words using gensim and sequence matching"
import pandas as pd
from difflib import SequenceMatcher
import string
from nltk.corpus import stopwords
from datetime import datetime
import config
import re
threshold=config.threshold
dumped=[]
stop_removd_list=[]
df=pd.DataFrame()
import stop_list
#------------------------------------------------------------------------------------
#----------------------------------CLASS DEFINED---------------------------------------------------
#
class s4x(object):
    def __init__(self):
        pass

    def threaded_env(self,cursor,src_data):
        global dumped
        global stop_removd_list
        global df
        results=[]
        k = 0
        src_data = src_data.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace(",","&#44;").replace("&#", "&amp;#").replace("'", "&apos;").replace("�", "&apos;").strip()
        pattern = re.compile(r'\b(' + r'|'.join(stop_list.list1_words) + r')\b\s*')
        src_data = pattern.sub('', src_data.lower().strip())
        now = datetime.now()
        current_time = now.strftime("%H:%M %p")
        print(current_time)
        if current_time==config.time1:
            dumped=[]
            stop_removd_list=[]
            df=pd.DataFrame()
            print("database refreshed in ist time zone")
            start_database=datetime.now()
            cursor.execute(
                "SELECT Comments FROM CoreAttemptedQuestion_CommentsValidation")
            for row in cursor.fetchall():
                dumped.append(row[0])
                pattern = re.compile(r'\b(' + r'|'.join(stop_list.list1_words) + r')\b\s*')
                stop_rmvd = pattern.sub('', row[0].lower().strip())
                stop_removd_list.append(stop_rmvd)
            df["original"] = dumped
            df["stopwords_removed"] = stop_removd_list
            print("checking len of dump in time 1", len(dumped))
            # print("time in database and stop words",datetime.now()-start_database)
        elif current_time==config.time2:
            dumped=[]
            stop_removd_list=[]
            df=pd.DataFrame()
            print("database refreshed in second time zone")
            start_database=datetime.now()
            cursor.execute(
                "SELECT Comments FROM CoreAttemptedQuestion_CommentsValidation")
            for row in cursor.fetchall():
                dumped.append(row[0])
                pattern = re.compile(r'\b(' + r'|'.join(stop_list.list1_words) + r')\b\s*')
                stop_rmvd = pattern.sub('', row[0].lower().strip())
                stop_removd_list.append(stop_rmvd)
            df["original"] = dumped
            df["stopwords_removed"] = stop_removd_list
            print("checking len of dump in time 2", len(dumped))
            # print("time in database and stop words",datetime.now()-start_database)
        else:
            print("checking len of dump in alltime", len(dumped))
            if len(dumped)==0:
                cursor.execute(
                    "SELECT Comments FROM CoreAttemptedQuestion_CommentsValidation")
                for row in cursor.fetchall():
                    dumped.append(row[0])
                    pattern = re.compile(r'\b(' + r'|'.join(stop_list.list1_words) + r')\b\s*')
                    stop_rmvd= pattern.sub('', row[0].lower().strip())
                    stop_removd_list.append(stop_rmvd)
                df["original"]=dumped
                df["stopwords_removed"]=stop_removd_list
                # print("in else if",len(dumped))
            else:
                print("printing_old data for vectorization")
        try:
            final_start = datetime.now()
            for idx, item in df.iterrows():
                j = item['original']
                l = item["stopwords_removed"]
                if len(results) != 0:
                    break
                else:
                    sim_score = SequenceMatcher(None, src_data.lower(), l.lower()).ratio()
                    if sim_score > threshold:
                        results.append({
                            'score': sim_score*100,
                            'doc': j,
                        })
                # if len(l) >= len(src_data)-30 and len(l) <= len(src_data)+25:
                #     if len(results)!=0:
                #         break
                #     else:
                #         sim_score = SequenceMatcher(None, src_data.lower(), l.lower()).ratio()
                #         if sim_score > threshold:
                #             results.append({
                #                 'score': sim_score*100,
                #                 'doc': j,
                #             })
                #         # results.sort(key=lambda k: k['score'], reverse=True)
                #         k+=1
            print("business logic time",datetime.now()-final_start)
            if len(results) == 0:
                results.append({
                    'score': 0,
                    'doc': "Did not match at 50 % threshold"})
            return results
        except Exception as e:
            raise Exception("error in dumping data from database: " + str(e))


# if __name__ == '__main__':
#     agents = 4
#     chunksize = 2
#     obj1=s4x()
#     source_data ='''You asked the questions to understand the customer&apos;s concern as related to lower the bill and wanted to remove the Cable and Phone service. You also asked the customer about Cable and phone services requirements. The customer believed that you understood her requirements and would give the best resolution. However&amp;#44; you could have asked the customer about Internet and XHS services utilization at customer&apos;s home&amp;#44; which could have given you the clarity about customer&apos;s needs and helped you to give the best resolution to the customer.
# '''
#     start = datetime.now()
#     results=obj1.threaded_env(check_data,source_data)
#     print(results)
#     # with Pool(processes=agents) as pool:
#     #     result = pool.map(threaded_env, [check_data], chunksize)
#     #     print(result)
#     print(datetime.now()-start)
#
