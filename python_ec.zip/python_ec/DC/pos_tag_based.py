from nltk import pos_tag
from nltk.tokenize import word_tokenize
from nltk.tokenize import sent_tokenize
import re
import html
from flask import request
from flask import Flask, jsonify
from flask import abort
import logging
from logging import Formatter, FileHandler

import pandas as pd
from flask_cors import CORS, cross_origin


# from practnlptools.tools import Annotator
# annotator=Annotator()

# import and clean data
# data = pd.read_excel('./Copy of SampleDataforAI (003).xlsx', sheetname= 'Sheet1')
#
# data['Comments'] = data['Comments'].astype(str)
#
# data_c = data.replace({'&amp;': ''}, regex=True)
# data_c = data_c.replace({'#\d+;': ''}, regex=True)
# data_c = data_c.replace({'&apos;': "'"}, regex=True)
# data_c = data_c.replace(r'\\n','', regex=True)

#suggest statement based on the missing comment category
def suggest(result):
    if result["status"]["observation"] == False:
        result["suggestion"]["observation"] = "You haven't mentioned your observation.\nPlease write statements like:\n'You missed to greet..."
    if result["status"]["impact_of_observation"] == False:
        result["suggestion"]["impact_of_observation"] = "You haven't mentioned the impact of your observation.\nPlease write statements like:\n'...  because of which the customer left the call..."
    if result["status"]["recommendation"] == False:
        result["suggestion"]["recommendation"] = "You haven't mentioned your recommendations.\nPlease write statements like:\n'You could have educated the customer..."
    return result

# pos tag the comment
def comment_category(comment):
    # clean comment
    comment = html.unescape(comment)
    comment = re.sub('&amp;', '', comment)
    comment = re.sub('#\d+;', '', comment)
    comment = re.sub('&apos;', "'", comment)
    comment = re.sub(r'\\n', '', comment)
    # break comment in sents
    sentences = sent_tokenize(comment)
    result = {"comment": comment,
              "status": {"observation": False,
                         "impact_of_observation": False,
                         "recommendation": False},
              "statements":{"observation":[],
                            "impact_of_observation": [],
                            "recommendation": []},
              "suggestion":{"observation":None,
                            "impact_of_observation": None,
                            "recommendation": None}}
    for sent in sentences:
        pos = pos_tag(word_tokenize(sent))
        for idx, p in enumerate(pos):
            # to identify observation
            if p[1] in ["NNP", "PRP"] and \
                    p[0].lower() not in ["customer", "she", "he"]:
                    # and \
                    # result["status"]["observation"] == False:
                try:
                    if any(x in [pos[idx + 1][1], pos[idx + 2][1]] for x in ["VBD","VBP","VBN"]):
                        result["status"]["observation"] = True
                        result["statements"]["observation"].append(sent)
                except:
                    pass
            # to identify recommendation
            if p[0].lower() in ["could", "should", "would", "recommend", "suggest"]:
                    # and \
                    # result["status"]["recommendation"] is False:
                result["status"]["recommendation"] = True
                result["statements"]["recommendation"].append(sent)
            # to identify impact_of_observation
            # rule1: WDT followed by customer or He/She
            if p[1] == 'WDT':
                    # and \
                    # result["status"]["impact_of_observation"] is False:
                try:
                    for i in range(idx, len(pos)):
                        if pos[i][0].lower() in ["could", "should", "would", "recommend", "suggest"]:
                            break
                        if pos[i][0].lower() in ["customer", "he", "she","him","her"]:
                            result["status"]["impact_of_observation"] = True
                            result["statements"]["impact_of_observation"].append(sent)
                except:
                    pass
    # take unique statements only
    result["statements"]["recommendation"] = list(set(result["statements"]["recommendation"]))
    result["statements"]["observation"] = list(set(result["statements"]["observation"]))
    result["statements"]["impact_of_observation"] = list(set(result["statements"]["impact_of_observation"]))
    result = suggest(result)
    return result


app = Flask(__name__)


@app.route('/check', methods=['POST'])
@cross_origin()
def create_task():
    content = request.get_json()

    if content['comment'] == None:
        app.logger.debug("\t" + "NA" + "\t" + "no comment in request")
        abort(400)
    comment = request.json.get('comment')
    app.logger.debug("\t" + str(content))
    #    try:
    result = comment_category(comment)
    response = jsonify(result)
    app.logger.debug("\t" + str(response.get_data()))
    return response


if __name__ == '__main__':
    file_handler = FileHandler('./logs/output.log')
    handler = logging.StreamHandler()
    file_handler.setLevel(logging.DEBUG)
    handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(Formatter(
        '%(asctime)s %(levelname)s: %(message)s '
        '[in %(pathname)s:%(lineno)d]'
    ))
    handler.setFormatter(Formatter(
        '%(asctime)s %(levelname)s: %(message)s '
        '[in %(pathname)s:%(lineno)d]'
    ))
    app.logger.addHandler(handler)
    app.logger.addHandler(file_handler)
    app.run(debug=True, host='172.30.15.102', port=5051)
