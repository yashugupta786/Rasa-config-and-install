import requests
import json
url = "http://192.168.54.74:1995/s4x_results_ser_nine"
payload ={"data":"how are you"}
header = {"Content-type": "application/json",
          }
r = requests.post(url, data=json.dumps(payload),headers=header)
print(r)
print(r.text)